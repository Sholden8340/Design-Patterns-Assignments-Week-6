﻿namespace assignment2
{
    public interface IComputerFactory
    {
        public Computer AssembleComputer();
    }
}