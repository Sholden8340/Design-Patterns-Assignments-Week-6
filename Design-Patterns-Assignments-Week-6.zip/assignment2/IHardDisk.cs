﻿namespace assignment2
{
    public interface IHardDisk
    {
        public void StoreData();
    }
}