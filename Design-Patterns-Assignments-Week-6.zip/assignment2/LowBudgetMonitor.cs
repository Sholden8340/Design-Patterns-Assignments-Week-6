﻿using System;

namespace assignment2
{
    public class LowBudgetMonitor : IMonitor
    {
        public void Display()
        {
            Console.WriteLine("displaying stuff very poor...");
        }
    }
}