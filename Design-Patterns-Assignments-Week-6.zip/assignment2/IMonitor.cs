﻿namespace assignment2
{
    public interface IMonitor
    {
        public void Display();
    }
}