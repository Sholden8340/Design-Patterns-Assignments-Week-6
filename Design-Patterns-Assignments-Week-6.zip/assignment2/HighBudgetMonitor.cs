﻿using System;

namespace assignment2
{
    public class HighBudgetMonitor : IMonitor
    {
        public void Display()
        {
            Console.WriteLine("displaying stuff very nice...");
        }
    }
}