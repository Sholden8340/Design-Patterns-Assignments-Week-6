﻿namespace assignment2
{
    public interface IProcessor
    {
        public void PerformOperation();
    }
}