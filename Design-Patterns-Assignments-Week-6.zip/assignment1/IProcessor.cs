﻿namespace assignment1
{
    public interface IProcessor
    {
        public void PerformOperation();
    }
}