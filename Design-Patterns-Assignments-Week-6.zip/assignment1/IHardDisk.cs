﻿namespace assignment1
{
    public interface IHardDisk
    {
        public void StoreData();
    }
}