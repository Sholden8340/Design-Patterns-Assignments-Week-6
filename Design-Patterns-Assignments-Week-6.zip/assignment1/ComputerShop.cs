﻿using System;

namespace assignment1
{
    public abstract class ComputerShop
    {
        public abstract Computer AssembleComputer();
    }
}