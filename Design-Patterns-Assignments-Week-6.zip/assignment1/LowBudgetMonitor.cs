﻿using System;

namespace assignment1
{
    public class LowBudgetMonitor : IMonitor
    {
        public void Display()
        {
            Console.WriteLine("displaying stuff very poor...");
        }
    }
}