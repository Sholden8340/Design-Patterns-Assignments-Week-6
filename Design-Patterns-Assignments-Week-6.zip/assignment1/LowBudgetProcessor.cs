﻿using System;

namespace assignment1
{
    public class LowBudgetProcessor : IProcessor
    {
        public void PerformOperation()
        {
            Console.WriteLine("performing operation not so quickly...");
        }
    }
}