﻿namespace assignment1
{
    public interface IMonitor
    {
        public void Display();
    }
}